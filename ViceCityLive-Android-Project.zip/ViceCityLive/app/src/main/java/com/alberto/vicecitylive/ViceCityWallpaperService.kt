package com.alberto.vicecitylive

import android.graphics.*
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDateTime
import kotlin.concurrent.thread
import kotlin.math.*
import kotlin.random.Random

/**
 * Vice City Live renderer.
 * Runs only while the live wallpaper is visible; weather is fetched in the background.
 */
class ViceCityWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = CityEngine()

    inner class CityEngine : Engine() {
        @Volatile private var running = false
        private var renderThread: Thread? = null
        private var day: Bitmap? = null
        private var night: Bitmap? = null
        @Volatile private var weatherCode = 0
        @Volatile private var cloudCover = 0
        @Volatile private var precipitation = 0f
        @Volatile private var windSpeed = 0f
        @Volatile private var lastFetch = 0L
        private var frame = 0L
        private val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val fx = Paint(Paint.ANTI_ALIAS_FLAG)
        private val drops = Array(150) { Drop(Random.nextFloat(), Random.nextFloat(), 0.55f + Random.nextFloat() * 1.2f) }
        private val stars = Array(75) { Star(Random.nextFloat(), Random.nextFloat() * 0.62f, 0.35f + Random.nextFloat() * 0.65f) }
        private val clouds = Array(7) { Cloud(Random.nextFloat(), 0.08f + Random.nextFloat() * 0.34f, 0.65f + Random.nextFloat() * 0.7f, 0.7f + Random.nextFloat() * 0.7f) }
        private var lightningUntil = 0L
        private var nextLightning = 0L

        init {
            day = BitmapFactory.decodeResource(resources, R.drawable.vice_city_day)
            night = BitmapFactory.decodeResource(resources, R.drawable.vice_city_night)
        }

        override fun onVisibilityChanged(visible: Boolean) {
            if (visible) { fetchWeather(); startRendering() } else stopRendering()
        }
        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            if (isVisible) startRendering()
        }
        override fun onSurfaceDestroyed(holder: SurfaceHolder) { stopRendering(); super.onSurfaceDestroyed(holder) }
        override fun onDestroy() {
            stopRendering()
            day?.recycle(); night?.recycle()
            super.onDestroy()
        }

        private fun startRendering() {
            if (running) return
            running = true
            renderThread = thread(name = "ViceCityLive-Renderer", isDaemon = true) {
                while (running) {
                    if (isVisible) drawFrame()
                    try { Thread.sleep(50) } catch (_: InterruptedException) { }
                    frame++
                    if (frame % 1200L == 0L) fetchWeather()
                }
            }
        }
        private fun stopRendering() {
            running = false
            renderThread?.interrupt()
            renderThread = null
        }
        private fun drawFrame() {
            var canvas: Canvas? = null
            try {
                canvas = surfaceHolder.lockCanvas()
                if (canvas != null) render(canvas)
            } catch (_: Exception) {
            } finally {
                if (canvas != null) try { surfaceHolder.unlockCanvasAndPost(canvas) } catch (_: Exception) { }
            }
        }

        private fun render(c: Canvas) {
            val w = c.width.toFloat(); val h = c.height.toFloat()
            val now = LocalDateTime.now()
            val hour = now.hour + now.minute / 60f + now.second / 3600f
            val nightLevel = nightBlend(hour)
            val rect = cropRect(day, w, h)
            day?.let { c.drawBitmap(it, null, rect, imagePaint) }
            if (nightLevel > 0.001f) {
                fx.color = Color.WHITE
                fx.alpha = (nightLevel * 255).roundToInt().coerceIn(0, 255)
                night?.let { c.drawBitmap(it, null, rect, fx) }
            }

            // Warm dawn/dusk and deep-blue night colour grading.
            val dusk = sunsetAmount(hour)
            if (dusk > 0f) fill(c, Color.rgb(255, 105, 115), (dusk * 35).roundToInt())
            if (nightLevel > 0f) fill(c, Color.rgb(8, 15, 43), (nightLevel * 75).roundToInt())

            drawStars(c, w, h, nightLevel)
            drawClouds(c, w, h, nightLevel)
            drawWeather(c, w, h, hour)
            drawFog(c, w, h)
            drawWater(c, w, h, nightLevel)
            if (System.currentTimeMillis() < lightningUntil) fill(c, Color.WHITE, 95)
        }

        private fun cropRect(bitmap: Bitmap?, w: Float, h: Float): RectF {
            if (bitmap == null) return RectF(0f, 0f, w, h)
            val scale = max(w / bitmap.width, h / bitmap.height)
            val dw = bitmap.width * scale; val dh = bitmap.height * scale
            return RectF((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f)
        }
        private fun smooth(a: Float, b: Float, x: Float): Float {
            val t = ((x - a) / (b - a)).coerceIn(0f, 1f)
            return t * t * (3f - 2f * t)
        }
        private fun nightBlend(hour: Float): Float {
            val dawn = 1f - smooth(5.2f, 7.8f, hour)
            val dusk = smooth(17.0f, 20.2f, hour)
            return max(dawn, dusk)
        }
        private fun sunsetAmount(hour: Float): Float =
            max(smooth(16.0f, 18.2f, hour) * (1f - smooth(19.0f, 20.8f, hour)),
                (1f - smooth(5.0f, 6.4f, hour)) * smooth(6.0f, 7.8f, hour))

        private fun fill(c: Canvas, color: Int, alpha: Int) {
            fx.shader = null; fx.color = color; fx.alpha = alpha.coerceIn(0, 255)
            c.drawRect(0f, 0f, c.width.toFloat(), c.height.toFloat(), fx)
        }
        private fun drawStars(c: Canvas, w: Float, h: Float, night: Float) {
            if (night < 0.15f) return
            stars.forEachIndexed { i, s ->
                val twinkle = 0.55f + 0.45f * sin(frame * 0.035f + i).toFloat()
                fx.color = Color.WHITE
                fx.alpha = (night * s.brightness * twinkle * 180).roundToInt().coerceIn(0, 180)
                val r = 0.8f + s.brightness * 1.1f
                c.drawCircle(s.x * w, s.y * h, r, fx)
            }
        }
        private fun drawClouds(c: Canvas, w: Float, h: Float, night: Float) {
            val amount = (0.12f + cloudCover / 100f * 0.88f).coerceIn(0.12f, 1f)
            clouds.forEachIndexed { i, cloud ->
                val drift = (frame * (0.00012f + windSpeed * 0.000008f) * cloud.speed)
                val x = ((cloud.x + drift) % 1.35f - 0.15f) * w
                val y = cloud.y * h
                val width = h * 0.16f * cloud.scale
                val height = width * 0.30f
                fx.color = if (night > 0.5f) Color.rgb(27, 34, 62) else Color.rgb(226, 224, 238)
                fx.alpha = (amount * 65).roundToInt()
                // Layered, soft elongated cloud banks rather than circular "UFO" shapes.
                c.drawOval(x, y, x + width, y + height, fx)
                c.drawOval(x + width * 0.16f, y - height * 0.38f, x + width * 0.63f, y + height * 0.72f, fx)
                c.drawOval(x + width * 0.48f, y - height * 0.22f, x + width * 0.91f, y + height * 0.78f, fx)
                c.drawOval(x + width * 0.65f, y + height * 0.08f, x + width * 1.18f, y + height, fx)
            }
        }
        private fun drawWeather(c: Canvas, w: Float, h: Float, hour: Float) {
            val rainMode = weatherCode in 51..67 || weatherCode in 80..82 || weatherCode in 95..99
            val storm = weatherCode >= 95
            if (weatherCode in 45..48) {
                fill(c, Color.rgb(170, 184, 202), 32)
            } else if (rainMode) {
                fill(c, Color.rgb(25, 38, 65), 48)
                drops.forEachIndexed { i, d ->
                    val x = d.x * w
                    val y = ((d.y + frame * 0.0035f * d.speed) % 1.18f) * h - h * 0.09f
                    fx.color = Color.rgb(210, 225, 255)
                    fx.alpha = if (storm) 150 else 105
                    fx.strokeWidth = if (precipitation > 2f) 2.0f else 1.2f
                    c.drawLine(x, y, x - 4f * d.speed, y + 18f * d.speed, fx)
                }
            }
            if (storm) {
                if (System.currentTimeMillis() > nextLightning && Random.nextInt(1000) < 5) {
                    lightningUntil = System.currentTimeMillis() + 110
                    nextLightning = System.currentTimeMillis() + 4500
                }
                if (System.currentTimeMillis() < lightningUntil) {
                    fx.color = Color.WHITE; fx.alpha = 180; fx.strokeWidth = 3f
                    val x = w * (0.25f + Random.nextFloat() * 0.5f)
                    val p = Path().apply { moveTo(x, 0f); lineTo(x - 18f, h * .12f); lineTo(x + 3f, h * .10f); lineTo(x - 25f, h * .28f) }
                    c.drawPath(p, fx)
                }
            }
        }
        private fun drawFog(c: Canvas, w: Float, h: Float) {
            val fog = when (weatherCode) {
                45, 48 -> 0.8f
                in 51..67 -> 0.18f
                else -> (cloudCover / 100f) * 0.10f
            }
            if (fog <= 0.01f) return
            for (i in 0..4) {
                val drift = (frame * (0.00022f + i * 0.00004f)) % 1.4f
                val x = (drift - 0.2f) * w
                val y = h * (0.47f + i * 0.095f)
                fx.shader = LinearGradient(0f, y, 0f, y + h * .12f,
                    intArrayOf(Color.TRANSPARENT, Color.argb((fog * 65).roundToInt(), 205, 213, 225), Color.TRANSPARENT),
                    null, Shader.TileMode.CLAMP)
                c.drawRect(x, y, x + w * 0.8f, y + h * .12f, fx)
            }
            fx.shader = null
        }
        private fun drawWater(c: Canvas, w: Float, h: Float, night: Float) {
            // Animated fine highlights stay in the water band, below the skyline.
            for (i in 0 until 34) {
                val phase = frame * (0.18f + (i % 5) * 0.035f)
                val x = ((i * 61f + phase) % (w + 100f)) - 50f
                val y = h * (0.665f + (i % 13) * 0.012f)
                val length = 7f + (i % 6) * 5f
                fx.color = if (night > .5f) Color.rgb(160, 190, 255) else Color.rgb(255, 205, 220)
                fx.alpha = (18 + night * 22).roundToInt()
                fx.strokeWidth = 1.2f
                c.drawLine(x, y, x + length, y, fx)
            }
        }
        private fun fetchWeather() {
            val now = System.currentTimeMillis()
            if (now - lastFetch < 15 * 60 * 1000L) return
            lastFetch = now
            thread(name = "ViceCityLive-Weather", isDaemon = true) {
                var conn: HttpURLConnection? = null
                try {
                    val prefs = getSharedPreferences("vice_city", MODE_PRIVATE)
                    val lat = prefs.getFloat("lat", 45.315f)
                    val lon = prefs.getFloat("lon", 8.858f)
                    val endpoint = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code,cloud_cover,precipitation,wind_speed_10m&timezone=auto"
                    conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 10000; readTimeout = 10000
                    }
                    val root = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                    val current = root.getJSONObject("current")
                    weatherCode = current.optInt("weather_code", 0)
                    cloudCover = current.optInt("cloud_cover", 0)
                    precipitation = current.optDouble("precipitation", 0.0).toFloat()
                    windSpeed = current.optDouble("wind_speed_10m", 0.0).toFloat()
                } catch (_: Exception) {
                    // Keep last known weather; time-based day/night animation continues offline.
                } finally { conn?.disconnect() }
            }
        }
    }

    private data class Drop(val x: Float, val y: Float, val speed: Float)
    private data class Star(val x: Float, val y: Float, val brightness: Float)
    private data class Cloud(val x: Float, val y: Float, val speed: Float, val scale: Float)
}
