package com.alberto.vicecitylive

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Color
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalTime
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class ViceCityWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = CityEngine()

    inner class CityEngine : Engine() {
        private var renderThread: Thread? = null
        @Volatile private var running = false
        private var day: Bitmap? = null
        private var night: Bitmap? = null
        @Volatile private var weatherCode = 0
        private var lastWeatherFetch = 0L
        private var temperature = ""
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val overlay = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rain = Array(90) { RainDrop(Random.nextFloat(), Random.nextFloat(), 0.35f + Random.nextFloat() * 0.8f) }
        private var frame = 0L

        init {
            day = BitmapFactory.decodeResource(resources, R.drawable.vice_city_day)
            night = BitmapFactory.decodeResource(resources, R.drawable.vice_city_night)
        }

        override fun onVisibilityChanged(visible: Boolean) {
            if (visible) { startRendering(); refreshWeatherIfNeeded() } else stopRendering()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            if (isVisible) startRendering()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) { stopRendering(); super.onSurfaceDestroyed(holder) }
        override fun onDestroy() { stopRendering(); day?.recycle(); night?.recycle(); super.onDestroy() }

        private fun startRendering() {
            if (running) return
            running = true
            renderThread = thread(name = "ViceCityRenderer", isDaemon = true) {
                while (running) {
                    if (isVisible) drawFrame()
                    try { Thread.sleep(100) } catch (_: InterruptedException) { }
                    frame++
                    if (frame % 300L == 0L) refreshWeatherIfNeeded()
                }
            }
        }

        private fun stopRendering() {
            running = false
            renderThread?.interrupt()
            renderThread = null
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) render(canvas)
            } catch (_: Exception) { }
            finally { if (canvas != null) try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) { } }
        }

        private fun render(c: Canvas) {
            val w = c.width.toFloat(); val h = c.height.toFloat()
            val now = LocalTime.now()
            val nightAmount = nightBlend(now.hour + now.minute / 60f)
            val dst = centerCropRect(day, w, h)
            day?.let { c.drawBitmap(it, null, dst, paint) }
            if (nightAmount > 0f) {
                overlay.color = Color.WHITE
                overlay.alpha = (nightAmount * 255).toInt().coerceIn(0, 255)
                night?.let { c.drawBitmap(it, null, dst, overlay) }
            }
            drawWeather(c, w, h)
            drawWaterGlints(c, w, h)
        }

        private fun centerCropRect(bitmap: Bitmap?, w: Float, h: Float): RectF {
            if (bitmap == null) return RectF(0f, 0f, w, h)
            val scale = max(w / bitmap.width, h / bitmap.height)
            val dw = bitmap.width * scale; val dh = bitmap.height * scale
            val left = (w - dw) / 2f
            val top = (h - dh) / 2f
            return RectF(left, top, left + dw, top + dh)
        }

        private fun nightBlend(hour: Float): Float {
            // Notte piena 22-05, transizioni morbide all'alba e al tramonto.
            fun smooth(a: Float, b: Float, x: Float): Float {
                val t = ((x - a) / (b - a)).coerceIn(0f, 1f)
                return t * t * (3f - 2f * t)
            }
            val dawn = 1f - smooth(5f, 8f, hour)
            val dusk = smooth(17f, 21.5f, hour)
            return max(dawn, dusk)
        }

        private fun drawWeather(c: Canvas, w: Float, h: Float) {
            when (weatherCode) {
                in 1..3, 45, 48 -> {
                    overlay.color = Color.rgb(75, 91, 130); overlay.alpha = if (weatherCode >= 45) 48 else 28
                    c.drawRect(0f, 0f, w, h, overlay)
                    drawClouds(c, w, h, if (weatherCode >= 45) 0.32f else 0.20f)
                    if (weatherCode >= 45) {
                        overlay.color = Color.WHITE; overlay.alpha = 22
                        c.drawRect(0f, h * 0.48f, w, h, overlay)
                    }
                }
                in 51..67, in 80..82, 95, 96, 99 -> {
                    overlay.color = Color.rgb(32, 43, 78); overlay.alpha = 68
                    c.drawRect(0f, 0f, w, h, overlay)
                    drawClouds(c, w, h, 0.42f)
                    overlay.color = Color.rgb(205, 220, 255); overlay.alpha = 145; overlay.strokeWidth = 1.6f
                    rain.forEachIndexed { i, drop ->
                        val x = drop.x * w
                        val y = ((drop.y + (frame * 0.006f * drop.speed)) % 1.15f) * h - h * 0.1f
                        c.drawLine(x, y, x - 5f, y + 17f, overlay)
                    }
                    if (weatherCode >= 95 && frame % 97L < 2L) {
                        overlay.color = Color.WHITE; overlay.alpha = 35
                        c.drawRect(0f, 0f, w, h, overlay)
                    }
                }
            }
        }

        private fun drawClouds(c: Canvas, w: Float, h: Float, strength: Float) {
            overlay.color = Color.rgb(45, 52, 91)
            overlay.alpha = (strength * 150f).toInt().coerceIn(0, 100)
            val drift = (frame * 0.12f) % (w + 220f)
            for (i in 0 until 5) {
                val baseX = ((i * (w / 4f) + drift) % (w + 220f)) - 110f
                val baseY = h * (0.16f + (i % 3) * 0.075f)
                val r = h * 0.018f
                c.drawOval(baseX - r, baseY, baseX + r * 2.8f, baseY + r * 1.2f, overlay)
                c.drawCircle(baseX + r * 0.7f, baseY, r, overlay)
                c.drawCircle(baseX + r * 1.5f, baseY - r * 0.15f, r * 0.9f, overlay)
            }
        }

        private fun drawWaterGlints(c: Canvas, w: Float, h: Float) {
            // Riflessi appena accennati nella fascia dell'acqua: niente overlay sulle icone in alto.
            overlay.color = Color.rgb(255, 188, 222); overlay.alpha = 22; overlay.strokeWidth = 1.2f
            val phase = frame * 0.035f
            for (i in 0 until 12) {
                val y = h * (0.67f + i * 0.012f)
                val x = ((i * 79f + phase * (i % 3 + 1)) % (w + 70f)) - 35f
                val len = 8f + (i % 4) * 5f
                c.drawLine(x, y, x + len, y, overlay)
            }
        }

        private fun refreshWeatherIfNeeded() {
            val now = System.currentTimeMillis()
            if (now - lastWeatherFetch < 30 * 60 * 1000L) return
            lastWeatherFetch = now
            thread(name = "ViceCityWeather", isDaemon = true) {
                try {
                    val prefs = getSharedPreferences("vice_city", MODE_PRIVATE)
                    val lat = prefs.getFloat("lat", 45.315f)
                    val lon = prefs.getFloat("lon", 8.858f)
                    val url = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code&timezone=auto")
                    val conn = (url.openConnection() as HttpURLConnection).apply { connectTimeout = 8000; readTimeout = 8000 }
                    val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                    val current = json.getJSONObject("current")
                    weatherCode = current.optInt("weather_code", 0)
                    temperature = current.optDouble("temperature_2m").toInt().toString()
                    conn.disconnect()
                } catch (_: Exception) { /* Mantiene l'ultima condizione nota / cielo sereno al primo avvio. */ }
            }
        }
    }

    private data class RainDrop(val x: Float, val y: Float, val speed: Float)
}
