package com.alberto.vicecitylive

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var cityInput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("vice_city", MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xFF101B3A.toInt())
        }
        val title = TextView(this).apply {
            text = "VICE CITY LIVE"
            textSize = 28f
            setTextColor(0xFFFF8EC8.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "La città cambia insieme alla tua giornata."
            textSize = 15f
            setTextColor(0xFFE7E9FF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, pad / 2, 0, pad * 2)
        }
        cityInput = EditText(this).apply {
            setSingleLine(true)
            hint = "Città (es. Vigevano)"
            setText(prefs.getString("city", "Vigevano"))
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFADB7DC.toInt())
        }
        val save = Button(this).apply {
            text = "SALVA LOCALITÀ"
            setOnClickListener { saveCity() }
        }
        val apply = Button(this).apply {
            text = "ANTEPRIMA E IMPOSTA SFONDO"
            setOnClickListener { openWallpaperPicker() }
        }
        status = TextView(this).apply {
            text = "Meteo aggiornato quando lo sfondo è attivo."
            textSize = 13f
            setTextColor(0xFFB8C4E8.toInt())
            gravity = Gravity.CENTER
            setPadding(0, pad, 0, pad)
        }
        val note = TextView(this).apply {
            text = "Animazioni leggere • Meteo reale Open-Meteo\nNessun account o chiave API richiesti."
            textSize = 12f
            setTextColor(0xFF9AA8D0.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())
        root.addView(subtitle, matchWrap())
        root.addView(cityInput, matchWrap())
        root.addView(save, matchWrap())
        root.addView(apply, matchWrap())
        root.addView(status, matchWrap())
        root.addView(note, matchWrap())
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun saveCity() {
        val city = cityInput.text.toString().trim()
        if (city.isBlank()) { cityInput.error = "Inserisci una città"; return }
        status.text = "Cerco la località…"
        io.execute {
            try {
                val encoded = URLEncoder.encode(city, "UTF-8")
                val url = URL("https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=1&language=it&format=json")
                val conn = (url.openConnection() as HttpURLConnection).apply { connectTimeout = 8000; readTimeout = 8000 }
                val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                val result = json.optJSONArray("results")?.optJSONObject(0)
                    ?: throw IllegalArgumentException("Località non trovata")
                val lat = result.getDouble("latitude")
                val lon = result.getDouble("longitude")
                val label = result.optString("name", city) + result.optString("admin1").let { if (it.isNotBlank()) ", $it" else "" }
                getSharedPreferences("vice_city", MODE_PRIVATE).edit()
                    .putString("city", label).putFloat("lat", lat.toFloat()).putFloat("lon", lon.toFloat()).apply()
                runOnUiThread { cityInput.setText(label); status.text = "Località salvata: $label" }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Non riesco a trovare la città. Controlla il nome e riprova." }
            }
        }
    }

    private fun openWallpaperPicker() {
        try {
            val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    ComponentName(this@MainActivity, ViceCityWallpaperService::class.java))
            }
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "Apri Sfondi e scegli Vice City Live", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() { super.onDestroy(); io.shutdown() }
}
