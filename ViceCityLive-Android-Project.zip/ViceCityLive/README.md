# Vice City Live 0.2

## Funzioni della versione 0.2
- Rendering continuo quando lo sfondo è visibile (circa 20 fotogrammi al secondo).
- Transizione giorno/notte graduale basata sull'ora locale del telefono.
- Color grading per notte e alba/tramonto.
- Nuvole stratificate in movimento, stelle con luminosità variabile.
- Pioggia animata, foschia/nebbia, lampi durante i temporali.
- Riflessi animati nella fascia dell'acqua.
- Dati correnti Open-Meteo: codice meteo, copertura nuvolosa, precipitazioni e vento.
- Aggiornamento meteo ogni 15 minuti circa; giorno/notte continua anche offline.

## Build
Il workflow GitHub Actions `Build Vice City Live APK` compila `:app:assembleDebug` e pubblica l'APK come artefatto `Vice-City-Live-APK`.

## Limiti noti
Gli effetti sono sovrapposizioni 2D disegnate in tempo reale sulle due illustrazioni incluse. Non è ancora una simulazione 3D: le finestre dei singoli edifici non sono controllate una per una e la pioggia non interagisce fisicamente con ogni superficie. I dati meteo provengono da Open-Meteo; l'ora e le transizioni sono calcolate localmente.
