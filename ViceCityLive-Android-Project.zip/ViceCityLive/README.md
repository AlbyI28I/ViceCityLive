# Vice City Live — live wallpaper Android

Progetto Android per uno sfondo animato che combina una scena Vice City originale con ora locale e meteo reale Open-Meteo.

## Cosa fa questa versione
- Live wallpaper Android selezionabile dal picker di sistema.
- Dissolvenza graduale tra artwork diurno e notturno in base all'ora locale.
- Meteo corrente reale tramite Open-Meteo, aggiornato ogni 30 minuti mentre lo sfondo è visibile.
- Cielo velato/nuvoloso, foschia, pioggia e temporali sovrapposti alla scena; pioggia e riflessi sull'acqua animati.
- Località configurabile dall'app tramite ricerca del nome (predefinita: Vigevano).
- Nessun account o API key richiesti per Open-Meteo.
- Rendering sospeso quando il wallpaper non è visibile.

## Ottenere l'APK senza PC (GitHub Actions)
1. Crea un repository GitHub vuoto chiamato `ViceCityLive` (può essere privato).
2. Carica il contenuto di questa cartella nella radice del repository, mantenendo anche `.github/workflows/build-apk.yml`.
3. Apri la scheda **Actions** e seleziona **Build Vice City Live APK**.
4. Premi **Run workflow**. Al termine, apri l'esecuzione completata e scarica l'artifact **Vice-City-Live-APK**.
5. Estrai lo ZIP dell'artifact sul telefono e installa `app-debug.apk`. Android potrebbe chiedere di autorizzare l'installazione da quella sorgente.

Il workflow compila l'app nel cloud con Java 17 e Gradle 8.11.1; non serve Android Studio né un computer locale.

## Build locale (facoltativa)
Aprire la cartella con Android Studio, JDK 17, Android SDK 35 e Gradle 8.11.1; eseguire `gradle :app:assembleDebug`.

## Attivazione
1. Apri **Vice City Live**.
2. Inserisci/salva la località desiderata (per esempio Vigevano).
3. Tocca **Anteprima e imposta sfondo**.
4. Nel selettore Android applicalo alla schermata Home.

## Limiti attuali
- L'app usa una località impostata manualmente, non il GPS automatico.
- Le transizioni giorno/notte fondono due artwork; non ci sono ancora scene dedicate a alba e tramonto.
- Le condizioni meteo vengono rappresentate con livelli grafici animati, non con una simulazione 3D fotorealistica.
- Il meteo viene aggiornato ogni 30 minuti quando lo sfondo è visibile; senza rete resta l'ultima condizione ricevuta.
- Il pacchetto non è ancora stato compilato o testato su un dispositivo reale. Il workflow GitHub genera l'APK e permette di verificarne la compilazione.

## Attribuzione meteo
I dati meteo sono forniti da Open-Meteo. Verificare i termini del servizio prima di distribuire pubblicamente l'app.
